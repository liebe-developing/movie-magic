import Hero from "./Hero";
import TopRatedMovies from "./TopRatedMovies";
import TopRatedSeries from "./TopRatedSeries";
import UpcomingMovies from "./UpcomingMovies";
import PopularSeries from "./PopularSeries";

export { Hero, TopRatedMovies, TopRatedSeries, UpcomingMovies, PopularSeries };
