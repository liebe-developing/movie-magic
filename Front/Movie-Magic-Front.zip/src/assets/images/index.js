import bgHero from "./bg-hero.avif";
import headerLogo from "./header-logo.png";
import moviePageBg from "./movie-page-bg.jpg";
import seriesPageBg from "./series-page-bg.jpg";
import contactPageBg from "./contact-page-bg.jpg";
import signinBg from "./signin-bg.jpg";
import signinBg2 from "./signin-bg2.jpg";
import aliRazmjue from "./ali-razmjue.png";
import abbas from "./abbas.jpg";
import map from "./map.jpg";

export {
  bgHero,
  headerLogo,
  moviePageBg,
  seriesPageBg,
  contactPageBg,
  signinBg,
  signinBg2,
  aliRazmjue,
  abbas,
  map,
};
