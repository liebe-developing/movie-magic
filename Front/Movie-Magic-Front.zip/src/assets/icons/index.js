import IMDBLogo from "./IMDb-Logo.png";
import ageIcon from "./age-icon.png";

export { IMDBLogo, ageIcon };
